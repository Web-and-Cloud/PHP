<?php

declare(strict_types=1);

namespace App\Controllers;

use App\TemplateEngine;
use App\Config\Paths;

class HomeController 
{

  private TemplateEngine $view;
  
  public function __construct()
  {
    $this->view = new TemplateEngine(Paths::VIEW);
  }

  public function home(){
    echo $this->view->render("/home.php", [
      'title' => 'Home page'
    ]);
  }
  
  public function about(){
    echo 'about page';
  }
}